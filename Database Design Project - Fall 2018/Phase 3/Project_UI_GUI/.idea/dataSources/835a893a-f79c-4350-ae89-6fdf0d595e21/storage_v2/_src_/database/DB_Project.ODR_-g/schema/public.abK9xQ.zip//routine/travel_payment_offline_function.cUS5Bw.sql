create function travel_payment_offline_function()
  returns trigger
language plpgsql
as $$
BEGIN
  IF new.onlinePeyment is false and new.travelSituation like 'finished'
  THEN
	UPDATE DRIVER set currency = currency - 0.05 * new.travelCost where phoneNumber like new.driverPhoneNumber;
  END IF;
  RETURN NEW;
END
$$;

