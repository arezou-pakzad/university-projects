create function travel_payment_online_function()
  returns trigger
language plpgsql
as $$
BEGIN
  IF new.onlinePeyment is true and new.travelSituation like 'finished'
  THEN
    UPDATE PASSENGER set currency = currency - new.travelCost where phoneNumber like new.passengerPhoneNumber;
	UPDATE DRIVER set currency = currency + 0.95 * new.travelCost where phoneNumber like new.driverPhoneNumber;
  END IF;
  RETURN NEW;
END
$$;

