create function charge_account_function()
  returns trigger
language plpgsql
as $$
BEGIN
  IF EXISTS (select * from travel WHERE passengerPhoneNumber = new.phoneNumber and travelSituation not like 'finished' and travelCost < new.currency)
  THEN
	UPDATE travel set onlinePeyment = true where passengerPhoneNumber like new.phoneNumber and travelSituation not like 'finished';
END IF;
RETURN NEW;
END
$$;

