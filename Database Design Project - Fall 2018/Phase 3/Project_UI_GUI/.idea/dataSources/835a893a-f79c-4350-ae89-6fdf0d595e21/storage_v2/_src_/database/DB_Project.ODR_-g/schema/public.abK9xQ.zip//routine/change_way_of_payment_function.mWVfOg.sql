create function change_way_of_payment_function()
  returns trigger
language plpgsql
as $$
BEGIN
  IF (select currency from passenger where phoneNumber like new.passengerPhoneNumber) > new.travelCost
  THEN
	UPDATE travel set onlinePeyment = true where travelCode = new.travelCode;
END IF;
RETURN NEW;
END
$$;

